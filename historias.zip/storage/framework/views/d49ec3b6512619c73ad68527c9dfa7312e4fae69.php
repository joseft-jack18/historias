

<?php $__env->startSection('titulo', 'Historias Clinicas'); ?>

<?php $__env->startSection('contenido'); ?>

    <!-- Main content -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Editar Paciente</h1>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <!-- general form elements -->
                    <div class="card">
                        <!-- form start -->
                        <form action="<?php echo e(route('persons.update', $person->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("PUT"); ?>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="id">Id Paciente</label>
                                            <input type="text" class="form-control" id="id" name="id" value="<?php echo e($person->id); ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="identity_document_type_id">Tipo Documento</label>
                                            <select class="form-control" id="identity_document_type_id" name="identity_document_type_id">
                                                <?php $__currentLoopData = $document_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($type->id); ?>" <?php if($type->id == $person->identity_document_type_id): ?> selected <?php endif; ?>><?php echo e($type->description); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="number">Nro Documento</label>
                                            <input type="text" class="form-control" id="number" name="number" value="<?php echo e($person->number); ?>" placeholder="Ingrese el número de documento" required>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label for="name">Apellidos y Nombres</label>
                                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($person->name); ?>" placeholder="Ingrese los nombres completos" required>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="birthdate">Fecha de Nacimiento</label>
                                            <input type="date" class="form-control" id="birthdate" name="birthdate" value="<?php echo e($person->birthdate); ?>" required>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="email">Correo Electrónico</label>
                                            <input type="email" class="form-control" id="email" name="email" value="<?php echo e($person->email); ?>" placeholder="Ingrese el correo del paciente">
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="telephone">Celular</label>
                                            <input type="text" class="form-control" id="telephone" name="telephone" value="<?php echo e($person->telephone); ?>" placeholder="Ingrese el celular del paciente" required>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="country_id">País</label>
                                            <select class="form-control" id="country_id" name="country_id">
                                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($country->id); ?>" <?php if($country->id == $person->country_id): ?> selected <?php endif; ?>><?php echo e($country->description); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>                                    
                                    <div class="col-8">
                                        <div class="form-group">
                                            <label for="address">Dirección</label>
                                            <input type="text" class="form-control" id="address" name="address" value="<?php echo e($person->address); ?>" placeholder="Ingrese la dirección del paciente" required>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /.card-body -->
                        
                            <div class="card-footer">
                                <button type="submit" class="btn btn-success"><i class='bx bx-save'></i> Editar</button>
                                <a href="<?php echo e(route('persons.index')); ?>">
                                    <button type="button" class="btn btn-default"><i class='bx bx-chevrons-left'></i> Cancelar</button>
                                </a>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->  
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\historias\resources\views/edit_person.blade.php ENDPATH**/ ?>