

<?php $__env->startSection('titulo', 'Historias Clinicas'); ?>

<?php $__env->startSection('contenido'); ?>

    <!-- Main content -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Listado de Historias Clínicas</h1>
                    <input type="hidden" name="mensaje" id="mensaje" value="<?php echo e(Session::get('success')); ?>">
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th class="text-center">#</th>
                                        <th class="text-center">F. Consulta</th>
                                        <th class="text-center">Motivo</th>
                                        <th class="text-center">Observaciones</th>
                                        <th class="text-center">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($numeracion); ?></td>
                                        <td class="text-center"><?php echo e($history->created_at); ?></td>
                                        <td><?php echo e($history->reason_consultation); ?></td>
                                        <td><?php echo e($history->observations); ?></td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('history.pdf', $history->id)); ?>" target="_blank" class="btn">
                                                <i class="bx bxs-file-pdf bx-sm" style="color: #D11111"></i>
                                            </a>
                                            <a href="<?php echo e(route('files.index', $history->id)); ?>" class="btn">
                                                <i class="bx bx-archive-in bx-sm" style="color: #158A12"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php echo e($numeracion++); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- /.card-body -->
                        <div class="card-footer clearfix">
                            <ul class="pagination pagination-sm m-0 float-right">
                                <li class="page-item"><a class="page-link" href="#">&laquo;</a></li>
                                <li class="page-item"><a class="page-link" href="#">1</a></li>
                                <li class="page-item"><a class="page-link" href="#">2</a></li>
                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                <li class="page-item"><a class="page-link" href="#">&raquo;</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script>
        let mensaje = $('#mensaje').val();
        if(mensaje != ''){
            toastr.success(mensaje)
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\historias\resources\views/histories.blade.php ENDPATH**/ ?>