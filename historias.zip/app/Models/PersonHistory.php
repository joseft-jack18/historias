<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PersonHistory extends Model
{
    use HasFactory;
    protected $table = 'person_history';
}
